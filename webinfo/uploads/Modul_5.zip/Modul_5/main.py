import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# после создания venv напишите в терминал pip install -r req.txt

df = pd.read_csv(
    "./data.csv", sep=",", on_bad_lines="skip", encoding="utf8"
)  # считываем базовые данные из таблицы csv

columns = df.columns.tolist()  # выделяем заголовки

# преобразуем данные в нужный формат для обучения
x = df[columns[0]].to_numpy()[:, None]
y = []
for i in range(1, 8):
    # добавляем в y данные для генерации синтетических записей(поскольку собрать большое
    # кол-во данных для конечного обучения не представляется возможным)
    y.append(df[columns[i]].to_numpy()[:, None])


# создаём 7 моделей линейной регрессии для создания синтетических данных каждого типа
models = [LinearRegression() for i in range(7)]

for j in range(0, 7):
    # обучаем модели для генерации данных
    models[j].fit(x, y[j])
# print(y)
# создаём синтетические данные на 50 лет вперёд
for i in range(2021, 2060):
    p = []
    for j in range(0, 7):
        a = models[j].predict([[i]])[0][0]
        if a < 10:
            a = round(a, 3)
        else:
            a = round(a, 0)
        # генерируем 7 типов данных и создаём из них массив
        p.append(a)
    # добавляем новые данные к основным
    df2 = pd.DataFrame([[i] + p], columns=columns, index=[i - 2010])

    df = pd.concat([df, df2])
#df.to_csv('./final.csv')

X_train, X_test, y_train, y_test = train_test_split(
    df[columns[1:7]], df[columns[7]], test_size=0.2, random_state=42
)  # разделяем данные для конечного обучения

model = LinearRegression()
# обучаем модель для предсказания данных о миграции
model.fit(X_train, y_train)

# предсказание на основе данных 2010 года
print(round(model.predict([[91698415.0, 1358109.0, 1451532.0, 1.133, 56847.0, 3214.0]])[0]))
