import tensorflow as tf
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import PIL.ImageOps 

import paint as p

model = tf.keras.models.load_model('model')

probability_model = tf.keras.Sequential([
  model,
  tf.keras.layers.Softmax()
])

p.main()

img = Image.open("image.png").convert("L").resize((28, 28))
img = PIL.ImageOps.invert(img)
img = np.array(img)

img = img.reshape(1, 28, 28)
img = img / 255.0

result = probability_model.predict(img)
print(result)

number = np.argmax(result)

print("The number is: ", number)