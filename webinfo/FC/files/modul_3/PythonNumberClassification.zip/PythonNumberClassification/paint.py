from tkinter import *
from PIL import ImageGrab

class Paint(Frame):
    def __init__(self, parent):
        Frame.__init__(self, parent)
        self.parent = parent

        self.brush_size = 5
        self.brush_color = "black"
        self.color = "black"

        self.parent.title("PyPaint")
        self.pack(fill=BOTH, expand=1)
 
        self.canv = Canvas(self, bg="white", width=500, height=500)
        self.canv.pack()
        self.canv.bind("<B1-Motion>", self.draw)

        self.save_btn = Button(self, text="Save", command=self.save)
        self.save_btn.pack()

    def save(self):
        filename = "image.png"
        x = self.parent.winfo_rootx() + self.canv.winfo_x()
        y = self.parent.winfo_rooty() + self.canv.winfo_y()
        x1 = x + self.canv.winfo_width()
        y1 = y + self.canv.winfo_height()
        thresh = 200
        fn = lambda x : 255 if x > thresh else 0
        a = ImageGrab.grab().crop((x,y,x1,y1)).convert("L").resize((28, 28)).point(fn, mode='1')
        a.save(filename)
        self.parent.destroy()

    def draw(self, event):
        self.canv.create_oval(event.x - self.brush_size,
                          event.y - self.brush_size,
                          event.x + self.brush_size,
                          event.y + self.brush_size,
                          fill=self.color, outline=self.color)

def main():
    root = Tk()
    root.geometry("500x600+300+300")
    app = Paint(root)
    root.mainloop()

